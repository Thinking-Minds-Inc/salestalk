<!--begin::Step 5-->
<div data-kt-stepper-element="content">
	<div class="w-100 text-center">
		<!--begin::Heading-->
		<h1 class="fw-bold text-gray-900 mb-3">Release!</h1>
		<!--end::Heading-->
		<!--begin::Description-->
		<div class="text-muted fw-semibold fs-3">Submit your app to kickstart your project.</div>
		<!--end::Description-->
		<!--begin::Illustration-->
		<div class="text-center px-4 py-15">
			<img src="<?php echo e(image('illustrations/sketchy-1/9.png')); ?>" alt="" class="mw-100 mh-300px" />
		</div>
		<!--end::Illustration-->
	</div>
</div>
<!--end::Step 5-->
<?php /**PATH /Users/faizal/Sites/keenthemes/_releases/metronic_v8.2.1/laravel/metronic_laravel_v8.2.1/starterkit/resources/views/partials/modals/create-app/steps/_step-5.blade.php ENDPATH**/ ?>