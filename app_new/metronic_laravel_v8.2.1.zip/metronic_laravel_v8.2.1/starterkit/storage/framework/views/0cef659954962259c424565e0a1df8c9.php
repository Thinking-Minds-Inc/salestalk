<!--begin::Drawers-->
<?php echo $__env->make('partials/drawers/_activity-drawer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials/drawers/_chat-messenger', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials/drawers/_shopping-cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--end::Drawers-->
<?php /**PATH /Users/faizal/Sites/keenthemes/_releases/metronic_v8.2.1/laravel/metronic_laravel_v8.2.1/starterkit/resources/views/partials/_drawers.blade.php ENDPATH**/ ?>