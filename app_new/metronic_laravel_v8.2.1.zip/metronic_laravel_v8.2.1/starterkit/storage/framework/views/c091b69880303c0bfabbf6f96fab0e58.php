<!--begin::Scrolltop-->
<div id="kt_scrolltop" class="scrolltop" data-kt-scrolltop="true"><?php echo getIcon('arrow-up', ''); ?></div>
<!--end::Scrolltop-->
<?php /**PATH /Users/faizal/Sites/keenthemes/_releases/metronic_v8.2.1/laravel/metronic_laravel_v8.2.1/starterkit/resources/views/partials/_scrolltop.blade.php ENDPATH**/ ?>