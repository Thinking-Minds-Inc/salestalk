<!--begin::Step 4-->
<div data-kt-stepper-element="content">
	<div class="w-100">
		<?php echo $__env->make('partials/modals/new-card/_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</div>
<!--end::Step 4-->
<?php /**PATH /Users/faizal/Sites/keenthemes/_releases/metronic_v8.2.1/laravel/metronic_laravel_v8.2.1/starterkit/resources/views/partials/modals/create-app/steps/_step-4.blade.php ENDPATH**/ ?>