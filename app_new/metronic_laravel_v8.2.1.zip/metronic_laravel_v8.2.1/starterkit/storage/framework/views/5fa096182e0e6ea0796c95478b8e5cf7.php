<!--begin::Footer-->
<div class="app-sidebar-footer flex-column-auto pt-2 pb-6 px-6" id="kt_app_sidebar_footer">
	<a href="https://1.envato.market/EA4JP" target="_blank" class="btn btn-flex flex-center btn-custom btn-primary overflow-hidden text-nowrap px-0 h-40px w-100" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-dismiss-="click" title="Purchase Metronic on ThemeForest">
	<span class="btn-label">Purchase Metronic</span><?php echo getIcon('document', 'btn-icon fs-2 m-0'); ?></a>
</div>
<!--end::Footer-->
<?php /**PATH /Users/faizal/Sites/keenthemes/_releases/metronic_v8.2.1/laravel/metronic_laravel_v8.2.1/starterkit/resources/views/layout/partials/sidebar-layout/sidebar/_footer.blade.php ENDPATH**/ ?>