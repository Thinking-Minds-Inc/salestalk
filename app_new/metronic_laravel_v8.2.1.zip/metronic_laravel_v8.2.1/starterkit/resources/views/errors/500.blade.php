<x-system-layout>
    @include('pages/system.error')
</x-system-layout>
