<!--begin::Drawers-->
@include('partials/drawers/_activity-drawer')
@include('partials/drawers/_chat-messenger')
@include('partials/drawers/_shopping-cart')
<!--end::Drawers-->
