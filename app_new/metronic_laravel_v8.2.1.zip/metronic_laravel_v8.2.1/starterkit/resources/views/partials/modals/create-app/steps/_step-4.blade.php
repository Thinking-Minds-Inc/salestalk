<!--begin::Step 4-->
<div data-kt-stepper-element="content">
	<div class="w-100">
		@include('partials/modals/new-card/_form')
	</div>
</div>
<!--end::Step 4-->
